
package com.example.books;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.books.adaptadores.ListaRecyclerAdaptador;
import com.example.books.databinding.FragmentListaLivrosBinding;
import com.example.books.modelo.Livro;
import com.example.books.modelo.SingletonGestorLivros;

import java.util.ArrayList;

public class ListaLivrosFragment extends Fragment implements ListaRecyclerAdaptador.OnLivroClickListener {

    public static final String LIVRO_ID = "livro_id";

    private FragmentListaLivrosBinding binding;
    private ListaRecyclerAdaptador adaptador;

    public ListaLivrosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentListaLivrosBinding.inflate(inflater, container, false);

        SingletonGestorLivros singleton = SingletonGestorLivros.getInstance();

        ArrayList<Livro> livros = singleton.getLivros();

        adaptador = new ListaRecyclerAdaptador(livros, this);

        binding.rvLivros.setLayoutManager(new LinearLayoutManager(requireContext()));

        binding.rvLivros.setAdapter(adaptador);

        return binding.getRoot();
    }

    @Override
    public void onLivroClick(Livro livro) {

        Intent intent = new Intent(requireContext(), DetalhesLivrosActivity.class);

        intent.putExtra(LIVRO_ID, livro.getId());

        startActivity(intent);
    }
}
