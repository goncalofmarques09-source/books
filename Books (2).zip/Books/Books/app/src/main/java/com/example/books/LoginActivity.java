package com.example.books;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.books.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;

    public static final String EMAIL = "EMAIL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        //setContentView(R.layout.activity_login);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }

    private boolean isEmailValido(String email){
        if(email != null && Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            return true;
        }
        return false;
    }

    private boolean isPasswordValida(String password){
        if(password != null && password.length() >= 4 ) {
            return true;
        }
        return false;
    }

    public void onClickLogin(View view) {
        String email = binding.etEmail.getText().toString();
        if(isEmailValido(email)) {
            String password = binding.etPassword.toString();
            if(isPasswordValida(password)){
                Toast.makeText(this, R.string.txt_login_bem_sucedido, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, MenuMainActivity.class);
                intent.putExtra(MenuMainActivity.EMAIL, email);
                startActivity(intent);
            }else{
                binding.etPassword.setError(getString(R.string.txt_password_invalida));
            }
        }else{
            binding.etEmail.setError(getString(R.string.txt_email_invalido));
        }
    }
}