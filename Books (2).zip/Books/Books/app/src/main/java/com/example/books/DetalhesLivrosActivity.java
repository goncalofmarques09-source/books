
package com.example.books;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.books.databinding.ActivityDetalhesLivrosBinding;
import com.example.books.modelo.Livro;
import com.example.books.modelo.SingletonGestorLivros;

public class DetalhesLivrosActivity extends AppCompatActivity {

    public static final String LIVRO_ID = "livro_id";

    private ActivityDetalhesLivrosBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        binding = ActivityDetalhesLivrosBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            return insets;
        });

        int id = getIntent().getIntExtra(LIVRO_ID, -1);

        Livro livro;

        if (id == -1) {
            // TODO Criação de um livro novo
        } else {
            livro = SingletonGestorLivros.getInstance().getLivro(id);

            if (livro != null) {
                binding.etTitulo.setText(livro.getTitulo());
                binding.etSerie.setText(livro.getSerie());
                binding.etAutor.setText(livro.getAutor());
                binding.etAno.setText(livro.getAno() + "");
                binding.imageView4.setImageResource(livro.getCapa());
            }
        }
    }
}
