
package com.example.books;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.books.databinding.ActivityMenuMainBinding;
import com.example.books.databinding.NavHeaderMainBinding;
import com.google.android.material.navigation.NavigationView;

public class MenuMainActivity extends AppCompatActivity {

    private ActivityMenuMainBinding binding;

    public static final String EMAIL = "EMAILLLLLLLLLL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);

        binding = ActivityMenuMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.toolbar, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        ViewCompat.setOnApplyWindowInsetsListener(binding.fragmentContainer, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            return insets;
        });

        String email = getIntent().getStringExtra(EMAIL);

        NavHeaderMainBinding headerBinding = NavHeaderMainBinding.bind(
                binding.navigationView.getHeaderView(0));

        headerBinding.tvEmail.setText(email);

        carregarToolbar();

        binding.navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                        return selecionarItemMenu(menuItem);
                    }
                });

        carregarFragmento(new ListaLivrosFragment());

        setTitle(R.string.txt_livros_lista);

        binding.navigationView.setCheckedItem(R.id.navEstatico);
    }

    private void carregarFragmento(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }

    private boolean selecionarItemMenu(MenuItem menuItem) {

        int id = menuItem.getItemId();

        if (id == R.id.navEstatico) {

            setTitle(R.string.txt_livros_lista);

            Toast.makeText(this, "Livro Estático", Toast.LENGTH_SHORT).show();

            carregarFragmento(new ListaLivrosFragment());

        } else if (id == R.id.navDinamico) {

            setTitle(R.string.txt_livros_grelha);

            Toast.makeText(this, "Livro Dinamico", Toast.LENGTH_SHORT).show();

            carregarFragmento(new GridLivrosFragment());

        } else {

            Toast.makeText(this, "Enviar Email", Toast.LENGTH_SHORT).show();
        }

        binding.drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    private void carregarToolbar() {

        setSupportActionBar(binding.toolbar);

        ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(
                this,
                binding.drawerLayout,
                binding.toolbar,
                R.string.menu_abrir,
                R.string.menu_fechar
        );

        binding.drawerLayout.addDrawerListener(drawerToggle);

        drawerToggle.syncState();

        drawerToggle.getDrawerArrowDrawable().setColor(
                ContextCompat.getColor(this, android.R.color.white));
    }
}
